package com.demo;

import com.demo.dao.RegisterDao;

public class RegisterAction {  
	private String iteam_name;
	private String model;
	private String bid_price;


	public RegisterAction() {
		
	}
public RegisterAction(String iteam_name, String model, String bid_price) {
		super();
		this.iteam_name = iteam_name;
		this.model = model;
		this.bid_price = bid_price;
	}



public String getIteam_name() {
		return iteam_name;
	}



	public void setIteam_name(String iteam_name) {
		this.iteam_name = iteam_name;
	}



	public String getModel() {
		return model;
	}



	public void setModel(String model) {
		this.model = model;
	}



	public String getBid_price() {
		return bid_price;
	}



	public void setBid_price(String bid_price) {
		this.bid_price = bid_price;
	}



@Override
	public String toString() {
		return "RegisterAction [iteam_name=" + iteam_name + ", model=" + model + ", bid_price=" + bid_price + "]";
	}



//setters and getters  
public String execute(){  
    int i=RegisterDao.save(this);  
    if(i>0){  
    return "success";  
    }  
    return "error";  
}  
}  