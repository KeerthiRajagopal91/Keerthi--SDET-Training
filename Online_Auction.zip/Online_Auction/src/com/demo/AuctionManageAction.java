package com.demo;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import com.demo.dao.BidUserData;

public class AuctionManageAction {

	
	ArrayList<BidUserData> list=new ArrayList<BidUserData>();  
	  
	public ArrayList<BidUserData> getList() {  
	    return list;  
	}  
	public void setList(ArrayList<BidUserData> list) {  
	    this.list = list;  
	}  
	public String execute(){  
	 try{  
		 Class.forName("com.mysql.jdbc.Driver");  
		 Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/demoseller","root","root");
	              
	  PreparedStatement ps=con.prepareStatement("select * from user");  
	  ResultSet rs=ps.executeQuery();  
	  
	  while(rs.next()){  
	   BidUserData data=new BidUserData();  
	   
	   data.setIteam_name(rs.getString(1));
	   data.setModel(rs.getString(2));
	   data.setAuction_Price(rs.getInt(3));
	   data.setName(rs.getString(4));
	   data.setEmail(rs.getString(5));
	   data.setPhone(rs.getString(6));
	   data.setAddress(rs.getString(7));
	   
	   
	   list.add(data);  
	  }  
	  
	  con.close();  
	 }catch(Exception e){e.printStackTrace();}  
	          
	 return "success";  
	}  
	
	
	
	
}
