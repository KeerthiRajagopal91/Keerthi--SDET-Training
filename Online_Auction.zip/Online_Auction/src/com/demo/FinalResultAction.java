package com.demo;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import com.demo.dao.BidUserData;

public class FinalResultAction {

	
	
	ArrayList<BidUserData> list=new ArrayList<BidUserData>();  
	  
	public ArrayList<BidUserData> getList() {  
	    return list;  
	}  
	public void setList(ArrayList<BidUserData> list) {  
	    this.list = list;  
	}  
	public String execute(){  
		int status=0;
	 try{  
		 Class.forName("com.mysql.jdbc.Driver");  
		 Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/demoseller","root","root");
		 
		 PreparedStatement ps1=con.prepareStatement("TRUNCATE TABLE seller");
		 status=ps1.executeUpdate(); 
	              
		 PreparedStatement ps=con.prepareStatement("select name, Auction_Price from user where Auction_Price = (select Max(Auction_Price) from user);");  
		 ResultSet rs=ps.executeQuery();  
	  
		 while(rs.next()){  
		 BidUserData data=new BidUserData();  
	   
		 data.setName(rs.getString(1));
		 data.setAuction_Price(rs.getInt(2));

	     list.add(data);  
	     
	     PreparedStatement ps2=con.prepareStatement("TRUNCATE TABLE user");
		 status=ps2.executeUpdate(); 
	  }  
	  
	  con.close();  
	 }catch(Exception e){e.printStackTrace();}  
	          
	 return "success";  
	}  
	
}
