package com.demo;

import java.util.Map;

import javax.servlet.http.HttpSession;

import org.apache.struts2.ServletActionContext;
import org.apache.struts2.dispatcher.SessionMap;
import org.apache.struts2.interceptor.SessionAware;

import com.demo.entity.User;
import com.opensymphony.xwork2.Action;

public class LoginAction implements SessionAware, Action {

//	private String userid;
//	private String password;
	private User user;// = new User(getUserid(), getPassword());
	private SessionMap<String, Object> sessionMap;
	
	@Override
	public void setSession(Map<String, Object> map) {
		sessionMap = (SessionMap)map;
	}
	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public String execute() {
//		System.out.println("UserId: "+getUserid());
//		System.out.println("Password: "+password);
//		User user = new User(getUserid(), getPassword());
		//System.out.println("Verify: in execute method: " + user);

		HttpSession session = ServletActionContext.getRequest().getSession(false);
		System.out.println(session);
		if (session == null || session.getAttribute("login")==null) {

			if (LoginService.verify(user)) {
				session = ServletActionContext.getRequest().getSession(true);

				sessionMap.put("name", user.getUserid());
				sessionMap.put("user", user);
				sessionMap.put("login", true);
				return SUCCESS;
			}
			return LOGIN;
		}
		return SUCCESS;
	}
	
	
	public String logout() {
		if(sessionMap!=null) {
			sessionMap.invalidate();
			sessionMap = null;
		}
		System.out.println("logged out...");
		return LOGIN;
	}

	
}