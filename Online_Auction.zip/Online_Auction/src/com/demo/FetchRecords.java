package com.demo;
import java.sql.*;  
import java.util.ArrayList;
import com.demo.entity.SellerData; 

//fetch records action class

public class FetchRecords {  
ArrayList<SellerData> list=new ArrayList<SellerData>();  
  
public ArrayList<SellerData> getList() {  
    return list;  
}  
public void setList(ArrayList<SellerData> list) {  
    this.list = list;  
}  
public String execute(){  
 try{  
	 Class.forName("com.mysql.jdbc.Driver");  
	 Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/demoseller","root","root");
              
  PreparedStatement ps=con.prepareStatement("Select * from seller limit 1;");  
  ResultSet rs=ps.executeQuery();  
  
  while(rs.next()){  
   SellerData data=new SellerData();  
   
   data.setIteam_name(rs.getString(1));
   data.setModel(rs.getString(2));
   data.setBid_price(rs.getString(3));
   
   list.add(data);  
  }  
  
  con.close();  
 }catch(Exception e){e.printStackTrace();}  
          
 return "success";  
}  
}  