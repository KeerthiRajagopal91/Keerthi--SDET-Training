package com.demo;

import com.demo.entity.User;

public class LoginService {

	public static boolean verify(User user){
		return user!=null&&user.getUserid()!=null&&user.getUserid().length()>0&&user.getUserid().equals(user.getPassword());
	}
}