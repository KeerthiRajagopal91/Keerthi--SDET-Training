package com.demo.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import com.demo.RegisterUserAction;

public class RegisterUserDao {

	
	public static int save(RegisterUserAction rs){  
		int status=0;  
		try{  
		Class.forName("com.mysql.jdbc.Driver");  
		Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/demoseller","root","root");  
		  
		PreparedStatement ps=con.prepareStatement("insert into user values(?,?,?,?,?,?,?)");
		ps.setString(1,rs.getIteam_name());
		ps.setString(2,rs.getModel());
		ps.setInt(3,rs.getAuction_Price());  
		ps.setString(4,rs.getName());  
		ps.setString(5,rs.getEmail());
		ps.setString(6,rs.getPhone());
		ps.setString(7,rs.getAddress());

		status=ps.executeUpdate();  
		  
		}catch(Exception e){e.printStackTrace();}  
		    return status;  
		}  
}
