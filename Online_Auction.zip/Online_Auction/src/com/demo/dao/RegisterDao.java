package com.demo.dao;
import java.sql.*;

import com.demo.RegisterAction;  
public class RegisterDao {  
  
public static int save(RegisterAction r){  
int status=0;  
try{  
Class.forName("com.mysql.jdbc.Driver");  
Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/demoseller","root","root");  
  
PreparedStatement ps=con.prepareStatement("insert into seller values(?,?,?)");
ps.setString(1,r.getIteam_name());  
ps.setString(2,r.getModel());  
ps.setString(3,r.getBid_price());  

status=ps.executeUpdate();  
  
}catch(Exception e){e.printStackTrace();}  
    return status;  
}  
}  