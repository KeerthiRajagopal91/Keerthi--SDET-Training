package com.demo.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

public class Truncate_ResultDao {
	
	
	public static  int truncate(){  
		int status=0;  
		try{  
		Class.forName("com.mysql.jdbc.Driver");  
		Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/demoseller","root","root");  
		  
		PreparedStatement ps=con.prepareStatement("TRUNCATE TABLE seller");
		

		status=ps.executeUpdate();  
		con.close();
		}catch(Exception e){e.printStackTrace();}  
		    return status;  
		}  
	
	
	  
	
	

}