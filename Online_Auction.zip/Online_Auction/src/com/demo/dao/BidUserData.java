package com.demo.dao;

public class BidUserData {
	private String Iteam_name;
	private String model;
	private int Auction_Price;
	private String name;
	private String email;
	private String phone;
	private String address;
	
	public BidUserData() {
		
	}
	
	public BidUserData(String iteam_name, String model, int auction_Price, String name, String email, String phone,
			String address) {
		super();
		Iteam_name = iteam_name;
		this.model = model;
		Auction_Price = auction_Price;
		this.name = name;
		this.email = email;
		this.phone = phone;
		this.address = address;
	}

	public String getIteam_name() {
		return Iteam_name;
	}

	public void setIteam_name(String iteam_name) {
		Iteam_name = iteam_name;
	}

	public String getModel() {
		return model;
	}

	public void setModel(String model) {
		this.model = model;
	}

	public int getAuction_Price() {
		return Auction_Price;
	}

	public void setAuction_Price(int auction_Price) {
		Auction_Price = auction_Price;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	@Override
	public String toString() {
		return "BidUserData [Iteam_name=" + Iteam_name + ", model=" + model + ", Auction_Price=" + Auction_Price
				+ ", name=" + name + ", email=" + email + ", phone=" + phone + ", address=" + address + "]";
	}
	
	

	
}
